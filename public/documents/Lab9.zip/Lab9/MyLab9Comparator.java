import java.util.*;
/**
 * MyLab9Comparator
 * Compares two Strings based on their appearance
 * If they're the same, compares them based on capitalization and alphabetical ordering
 * 
 * @author J Feustel 
 * @version 5/6/2014
 */
public class MyLab9Comparator implements Comparator<Map.Entry<String, Integer>>
{
   public int compare(Map.Entry<String, Integer> e1, Map.Entry<String, Integer> e2)
   {
      if(e1.getValue().compareTo(e2.getValue()) < 0)
         return 1;
      if(e1.getValue().compareTo(e2.getValue()) > 0)
         return -1;
      if(e1.getKey().compareTo(e2.getKey()) > 0)
         return 1;
      if(e1.getKey().compareTo(e2.getKey()) < 0)
         return -1;
      return 0;
   }
}
