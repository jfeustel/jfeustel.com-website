import java.util.*;
import java.io.*;
/**
 * Lab9
 * Reads text from a file and separates the words
 * Determine how many time each word appears
 * Returns the words in order of appearance frequency, capitalization,
 * and alphabetical order
 * 
 * @author J Feustel
 * @version 5/6/2014
 */
public class Lab9
{
   public static void main(String[] args)
   {
      Scanner in = null;
      try
      {
         in = new Scanner(new File("test.txt"));
         HashMap<String, Integer> myMap = new HashMap<String, Integer>();
         
         while (in.hasNext())
         {
            String word = in.next();
            
            if (myMap.containsKey(word))
               myMap.put(word, myMap.get(word) + 1);
            else
               myMap.put(word, 1);
         }
         TreeSet<Map.Entry<String, Integer>>  myTreeSet = new TreeSet<Map.Entry<String, 
                                                          Integer>>(new MyLab9Comparator());
         myTreeSet.addAll(myMap.entrySet());
         Iterator<Map.Entry<String, Integer>> itr = myTreeSet.iterator();
         while (itr.hasNext())
         {
            Map.Entry<String, Integer> entry = itr.next();
            System.out.println(entry.getKey() + " " + entry.getValue());
         }
         System.out.println("Done. Normal termination.");
      }
      catch (FileNotFoundException ex)
      {
         System.out.println("There was a problem opening the file: " + ex);
      }
      catch (Exception ex)
      {
         System.out.println("General exception");  
      }
      finally
      {
          if (in != null)
             in.close();
      }
   }
}